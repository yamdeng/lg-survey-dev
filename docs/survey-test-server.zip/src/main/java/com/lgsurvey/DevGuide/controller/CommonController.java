package com.lgsurvey.DevGuide.controller;

public class CommonController {

  // api/v1/profile
  // api/v1/initData
  // api/v1/auth/login
  // api/v1/auth/refresh
  // api/v1/test/file-upload1, api/v1/test/file-upload2
  // api/v1/error/auth, api/v1/error/notfound, api/v1/error/not-forbidden, api/v1/error/server-error

}

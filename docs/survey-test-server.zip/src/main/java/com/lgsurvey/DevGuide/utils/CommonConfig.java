package com.lgsurvey.DevGuide.utils;

public class CommonConfig {

  public static final String treeRootKey = "-1"; /* 트리 기본 최상의 upper 키 */

  public static final String authHeaderKey = "Authorization";

}

package com.lgsurvey.DevGuide.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lgsurvey.DevGuide.dto.CommonFileDto;
import com.lgsurvey.DevGuide.dto.CommonFilePathDto;
import com.lgsurvey.DevGuide.service.CommonFileService;
import com.lgsurvey.DevGuide.utils.CommonUtil;
import com.lgsurvey.DevGuide.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.List;
import java.util.Map;

@Tag(name = "공통 파일", description = "공통 파일 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1")
public class CommonFileController {

  @Autowired
  private CommonFileService commonFileService;

  @Operation(summary = "공통 파일 상세 조회", description = "공통 파일 상세 조회 API")
  @GetMapping("/common-file/{id}")
  public ResponseEntity<?> selectCommonFile(
      @PathVariable(value = "id", required = true) String id) {

    CommonFileDto result = commonFileService.selectFileDetail(id);

    return ResponseUtil.createSuccessResponse(result);
  }

  @Operation(summary = "공통 파일 목록 조회", description = "공통 파일 목록 조회 API")
  @GetMapping("/common-file")
  public ResponseEntity<?> selectCommonFileList(
      @RequestParam(value = "pageNum", required = false, defaultValue = "1") int pageNum,
      @RequestParam(value = "pageSize", required = false, defaultValue = "1000") int pageSize) {

    CommonFileDto paramDto = new CommonFileDto();

    // Page 조회
    PageHelper.startPage(pageNum, pageSize);
    PageInfo<CommonFileDto> pageList = commonFileService.selectFileList(paramDto);

    return ResponseUtil.createSuccessResponse(pageList);
  }

  @Operation(summary = "공통 파일 등록", description = "공통 파일 등록 API")
  @PostMapping(value = "/common-file")
  public ResponseEntity<?> createCommonFile(
      @Valid @RequestBody(required = true) CommonFileDto reqDto) {

    commonFileService.insertFile(reqDto);

    return ResponseUtil.createSuccessResponse();
  }

  @Operation(summary = "공통 파일 수정", description = "공통 파일 수정 API")
  @PutMapping(value = "/common-file/{id}")
  public ResponseEntity<?> updateCommonFile(@PathVariable(value = "id", required = true) String id,
      @Valid @RequestBody(required = true) CommonFileDto reqDto) {

    commonFileService.updateFile(reqDto);

    return ResponseUtil.createSuccessResponse();
  }

  @Operation(summary = "공통 파일 삭제", description = "공통 파일 삭제 API")
  @DeleteMapping(value = "/common-file/{id}")
  public ResponseEntity<?> deleteCommonFile(
      @PathVariable(value = "id", required = true) String id) {

    commonFileService.deleteFile(id);

    return ResponseUtil.createSuccessResponse();
  }

  @Operation(summary = "파일 업로드", description = "파일 업로드 API")
  @PostMapping(value = "/common-file/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
  public ResponseEntity<?> uploadFile(
      @RequestParam(value = "subModuleName", required = false, defaultValue = "common")
      String subModuleName,
      @RequestPart(value = "files", required = true) List<MultipartFile> files) {

    Map<String, Object> result = commonFileService.uploadFile(files);

    return ResponseUtil.createSuccessResponse(result);
  }

  @Operation(summary = "파일 다운로드", description = "파일 다운로드 API")
  @GetMapping(value = "/common-file/{fileKey}/download",
      produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
  public ResponseEntity<?> downloadFile(@PathVariable(value = "fileKey") String fileKey) {

    CommonFileDto dto = commonFileService.selectFileDetail(fileKey);

    return commonFileService.downloadFile(dto);
  }

  @Operation(summary = "파일 다운로드(이미지 preview)", description = "파일 다운로드(이미지 preview) API")
  @GetMapping("/common-file/{fileKey}/imageDownload")
  public ResponseEntity<Resource> previewImage(@PathVariable String fileKey,
      @RequestParam(value = "thumbnailYn", required = false, defaultValue = "N") String thumbnailYn)
      throws IOException {

    CommonFileDto fileInfo = commonFileService.selectFileDetail(fileKey);
    String fileExt = fileInfo.getFileExt();
    CommonFilePathDto filePathDto = commonFileService.getFileFullPath(fileInfo);
    Path filePath = Paths.get(thumbnailYn.equals("Y") ?
        filePathDto.getThumbnailFileFullPath() :
        filePathDto.getFileFullPath());
    Resource resource = new UrlResource(filePath.toUri());

    return ResponseEntity.ok().header(HttpHeaders.CONTENT_TYPE, CommonUtil.getMimeType(fileExt))
        .body(resource);
  }


  /**
   * 썸네일 Base64 데이터를 이미지로 변환하여 다운로드 (브라우저 미리보기 가능)
   */
  @GetMapping("/common-file/{fileKey}/imageDownloadByString")
  public ResponseEntity<byte[]> downloadThumbnail(@PathVariable String fileKey) {

    CommonFileDto fileInfo = commonFileService.selectFileDetail(fileKey);
    String base64String = fileInfo.getBase64String();
    if (base64String == null || base64String.isEmpty()) {
      return ResponseEntity.notFound().build();
    }

    // Base64 → 바이트 배열 변환
    byte[] imageBytes = Base64.getDecoder().decode(base64String);

    // Content-Type 설정 (기본: image/jpeg)
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.IMAGE_JPEG);

    return ResponseEntity.ok().headers(headers).body(imageBytes);
  }

}

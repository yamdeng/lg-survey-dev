package com.lgsurvey.DevGuide.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@ToString(callSuper = true)
@SuperBuilder
@NoArgsConstructor
public class NoticeBoardDto extends CommonDto {
  @Schema(description = "게시판 키")
  private String boardKey;

  @Schema(description = "게시판 유형")
  private String boardType;

  @Schema(description = "게시판 제목")
  private String boardTitle;

  @Schema(description = "게시판 내용")
  private String boardContent;
}

package com.lgsurvey.DevGuide.service;

import com.github.pagehelper.PageInfo;
import com.lgsurvey.DevGuide.common.AbstractCommonDaoService;
import com.lgsurvey.DevGuide.dto.NoticeBoardDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class NoticeBoardServiceImpl extends AbstractCommonDaoService implements NoticeBoardService {

  /**
   * 공지사항 상세 조회
   */
  public NoticeBoardDto selectNoticeDetail(String boardKey) {
    return commonSqlDao.selectOne("NoticeBoard.selectDetail", boardKey);
  }

  /**
   * 공지사항 목록 조회 (검색 포함)
   */
  public PageInfo<NoticeBoardDto> selectNoticeList(NoticeBoardDto paramDto) {
    List<NoticeBoardDto> resultList =
        commonSqlDao.selectList("NoticeBoard.selectList", paramDto);
    return PageInfo.of(resultList);
  }

  /**
   * 공지사항 등록
   */
  public NoticeBoardDto createNotice(NoticeBoardDto dto) {
    commonSqlDao.insert("NoticeBoard.insert", dto);
    return this.selectNoticeDetail(dto.getBoardKey());
  }

  /**
   * 공지사항 수정
   */
  public void updateNotice(NoticeBoardDto dto) {
    commonSqlDao.update("NoticeBoard.update", dto);
  }

  /**
   * 공지사항 삭제
   */
  public void deleteNotice(String boardKey) {
    commonSqlDao.delete("NoticeBoard.delete", boardKey);
  }
}

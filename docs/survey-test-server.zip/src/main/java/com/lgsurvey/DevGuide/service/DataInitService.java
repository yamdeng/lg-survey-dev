package com.lgsurvey.DevGuide.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgsurvey.DevGuide.common.AbstractCommonDaoService;
import com.lgsurvey.DevGuide.dto.*;
import com.lgsurvey.DevGuide.utils.CommonConfig;
import com.lgsurvey.DevGuide.utils.CommonUtil;
import com.lgsurvey.DevGuide.utils.DataUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Service
public class DataInitService extends AbstractCommonDaoService implements CommandLineRunner {

  private final CommonGroupCodeService commonGroupCodeService;
  private final CommonCodeService commonCodeService;

  private final ObjectMapper objectMapper;

  private final CommonDeptService commonDeptService;
  private final CommonUserService commonUserService;


  @Override
  @Transactional
  public void run(String... args) {
    initData();
  }

  private void initData() {
    createPosition();
    saveBatchStep1();
    checkCodeTable();
    checkMenuTable();
  }

  private void createPosition() {
    List<CommonPositionDto> positionDtoList = new ArrayList<>();

    commonSqlDao.insert("CommonPosition.insert",
        CommonPositionDto.builder().positionKey("P01").positionTitle("사원").sortIndex(1).build());
    commonSqlDao.insert("CommonPosition.insert",
        CommonPositionDto.builder().positionKey("P02").positionTitle("대리").sortIndex(2).build());
    commonSqlDao.insert("CommonPosition.insert",
        CommonPositionDto.builder().positionKey("P03").positionTitle("과장").sortIndex(3).build());
    commonSqlDao.insert("CommonPosition.insert",
        CommonPositionDto.builder().positionKey("P04").positionTitle("차장").sortIndex(4).build());
    commonSqlDao.insert("CommonPosition.insert",
        CommonPositionDto.builder().positionKey("P05").positionTitle("부장").sortIndex(5).build());
    commonSqlDao.insert("CommonPosition.insert",
        CommonPositionDto.builder().positionKey("P06").positionTitle("이사").sortIndex(6).build());
    commonSqlDao.insert("CommonPosition.insert",
        CommonPositionDto.builder().positionKey("P99").positionTitle("대표").sortIndex(99).build());

  }

  private void checkCodeTable() {

    try {
      // JSON 파일 로드
      ClassPathResource resource = new ClassPathResource("init-json/init-group-code.json");
      InputStream inputStream = resource.getInputStream();
      List<CommonGroupCodeDto> commonGroupCodeDtoList =
          objectMapper.readValue(inputStream, new TypeReference<List<CommonGroupCodeDto>>() {
          });
      for (CommonGroupCodeDto commonGroupCodeDto : commonGroupCodeDtoList) {
        if (commonSqlDao.selectOne("CommonGroupCode.selectDetail", commonGroupCodeDto) == null) {
          commonSqlDao.insert("CommonGroupCode.insert", commonGroupCodeDto);
        }
      }

      ClassPathResource resource2 = new ClassPathResource("init-json/init-code.json");
      InputStream inputStream2 = resource2.getInputStream();
      List<CommonCodeDto> commonCodeDtoList =
          objectMapper.readValue(inputStream2, new TypeReference<List<CommonCodeDto>>() {
          });
      for (CommonCodeDto commonCodeDto : commonCodeDtoList) {
        if (commonSqlDao.selectOne("CommonCode.selectDetail", commonCodeDto) == null) {
          commonSqlDao.insert("CommonCode.insert", commonCodeDto);
        }
      }

    } catch (IOException e) {
      log.error("init-json/init-code.json import error : {}", e);
    }
  }

  private void checkMenuTable() {

    try {
      // JSON 파일 로드
      ClassPathResource resource = new ClassPathResource("init-json/init-menu.json");
      InputStream inputStream = resource.getInputStream();
      List<CommonMenuDto> userMenuDtoList =
          objectMapper.readValue(inputStream, new TypeReference<List<CommonMenuDto>>() {
          });
      for (CommonMenuDto userMenuDto : userMenuDtoList) {
        if (commonSqlDao.selectOne("CommonMenu.selectDetail", userMenuDto) == null) {
          if (CommonUtil.isEmpty(userMenuDto.getMenuKey())) {
            userMenuDto.setMenuKey(CommonUtil.generateKey());
          }
          commonSqlDao.insert("CommonMenu.insert", userMenuDto);
        }
      }

    } catch (IOException e) {
      log.error("init-json/init-menu.json import error : {}", e);
    }
  }

  private void saveBatchStep1() {
    List<String> authStringList = new ArrayList<>();

    commonDeptService.createDept(CommonDeptDto.builder().deptKey("TOP").deptName("대표이사")
        .upperDeptKey(CommonConfig.treeRootKey).useYn("Y").sortIndex(1).build());

    String topUserKey = CommonUtil.generateKey();
    CommonUserDto userSaveDto =
        CommonUserDto.builder().userKey(topUserKey).userId(topUserKey).deptKey("TOP")
            .userName("LG대표이사").positionKey("P99").useYn("Y").build();

    commonUserService.createUser(userSaveDto);

    for (int index = 1; index <= 10; index++) {
      String deptKey = "LG_DEPT" + index;
      commonDeptService.createDept(
          CommonDeptDto.builder().deptKey(deptKey).deptName("전략기획실" + index).upperDeptKey("TOP")
              .useYn("Y").sortIndex(index).build());

      for (int subIndex = 1; subIndex <= 100; subIndex++) {
        String subUserKey = CommonUtil.generateKey();
        commonUserService.createUser(
            CommonUserDto.builder().userKey(subUserKey).userId(subUserKey).positionKey("P02")
                .deptKey(deptKey).userName("전략" + index + "_안용성" + subIndex).useYn("Y")
                .userType("U").build());
      }
    }
  }

}

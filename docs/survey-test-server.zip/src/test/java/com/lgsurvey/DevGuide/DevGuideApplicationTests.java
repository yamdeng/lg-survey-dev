package com.lgsurvey.DevGuide;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevGuideApplicationTests {

	@Test
	void contextLoads() {
	}

}
